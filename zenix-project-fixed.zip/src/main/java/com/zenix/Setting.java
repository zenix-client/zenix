package com.zenix;
public class Setting {
  public final String name; public double value, min, max; public final boolean bool;
  public Setting(String n, boolean v) { name = n; bool = true; value = v ? 1 : 0; }
  public Setting(String n, double v, double min, double max) { name = n; bool = false; value = v; this.min = min; this.max = max; }
  public boolean on() { return value > 0.5; }
  public float f() { return (float) value; }
}
