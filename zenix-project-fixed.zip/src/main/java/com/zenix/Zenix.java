package com.zenix;
import com.google.gson.*;
import com.zenix.gui.ClickGui;
import com.zenix.Module.Category;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import java.nio.file.*;
import java.util.*;

public class Zenix implements ClientModInitializer {
  public static final List<Module> MODULES = new ArrayList<>();
  public static Module ambience, arrows, clickgui;
  static final Path CFG = FabricLoader.getInstance().getConfigDir().resolve("zenix.json");
  static final boolean[] down = new boolean[GLFW.GLFW_KEY_LAST + 1];

  @Override public void onInitializeClient() {
    ambience = new Module("Ambience", Category.VISUAL)
      .add(new Setting("Custom Time", false)).add(new Setting("Time", 6000, 0, 24000))
      .add(new Setting("Weather (0 clear,1 rain,2 storm)", 0, 0, 2))
      .add(new Setting("Fog", true)).add(new Setting("Fog Red", 0, 0, 255)).add(new Setting("Fog Green", 200, 0, 255))
      .add(new Setting("Fog Blue", 160, 0, 255)).add(new Setting("Fog Distance %", 60, 10, 150)).add(new Setting("Fog Density %", 50, 0, 100));
    arrows = new Module("Arrows", Category.VISUAL)
      .add(new Setting("Size", 6, 3, 16)).add(new Setting("Radius", 40, 20, 120)).add(new Setting("Range", 64, 8, 256))
      .add(new Setting("Red", 0, 0, 255)).add(new Setting("Green", 229, 0, 255)).add(new Setting("Blue", 160, 0, 255))
      .add(new Setting("Alpha", 220, 20, 255));
    clickgui = new Module("ClickGUI", Category.CLIENT); clickgui.key = GLFW.GLFW_KEY_RIGHT_SHIFT; clickgui.enabled = true;
    MODULES.addAll(List.of(ambience, arrows, clickgui));
    load();
    ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    HudRenderCallback.EVENT.register(this::hud);
    Runtime.getRuntime().addShutdownHook(new Thread(Zenix::save));
  }

  void tick(MinecraftClient mc) {
    if (mc.getWindow() == null) return;
    long w = mc.getWindow().getHandle();
    if (mc.currentScreen == null) for (Module m : MODULES) if (m.key > 0) {
      boolean d = InputUtil.isKeyPressed(w, m.key);
      if (d && !down[m.key]) { if (m == clickgui) mc.setScreen(new ClickGui()); else m.toggle(); }
      down[m.key] = d;
    }
    if (mc.world != null && ambience.enabled) {
      if (ambience.get("Custom Time").on()) mc.world.getLevelProperties().setTimeOfDay((long) ambience.get("Time").value);
      int wx = (int) ambience.get("Weather (0 clear,1 rain,2 storm)").value;
      mc.world.setRainGradient(wx >= 1 ? 1f : 0f); mc.world.setThunderGradient(wx == 2 ? 1f : 0f);
    }
  }

  void hud(DrawContext ctx, net.minecraft.client.render.RenderTickCounter tc) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (!arrows.enabled || mc.world == null || mc.player == null || mc.currentScreen != null) return;
    int size = (int) arrows.get("Size").value, rad = (int) arrows.get("Radius").value;
    double range = arrows.get("Range").value;
    int col = ((int) arrows.get("Alpha").value << 24) | ((int) arrows.get("Red").value << 16) | ((int) arrows.get("Green").value << 8) | (int) arrows.get("Blue").value;
    Vec3d me = mc.player.getPos();
    int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
    for (PlayerEntity p : mc.world.getPlayers()) {
      if (p == mc.player) continue;
      double dx = p.getX() - me.x, dz = p.getZ() - me.z;
      if (dx * dx + dz * dz > range * range) continue;
      float rel = MathHelper.wrapDegrees((float) Math.toDegrees(Math.atan2(dz, dx)) - 90f - mc.player.getYaw());
      double r = Math.toRadians(rel);
      ctx.getMatrices().push();
      ctx.getMatrices().translate(cx + Math.sin(r) * rad, cy - Math.cos(r) * rad, 0);
      ctx.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rel));
      for (int i = 0; i < size; i++) ctx.fill(-i / 2, i - size / 2, i / 2 + 1, i - size / 2 + 1, col);
      ctx.getMatrices().pop();
    }
  }

  public static void save() {
    try {
      JsonObject o = new JsonObject();
      for (Module m : MODULES) {
        JsonObject j = new JsonObject(); j.addProperty("enabled", m.enabled); j.addProperty("key", m.key);
        for (Setting s : m.settings) j.addProperty(s.name, s.value);
        o.add(m.name, j);
      }
      Files.writeString(CFG, new GsonBuilder().setPrettyPrinting().create().toJson(o));
    } catch (Exception e) { e.printStackTrace(); }
  }
  static void load() {
    try {
      if (!Files.exists(CFG)) return;
      JsonObject o = JsonParser.parseString(Files.readString(CFG)).getAsJsonObject();
      for (Module m : MODULES) if (o.has(m.name)) {
        JsonObject j = o.getAsJsonObject(m.name);
        if (j.has("enabled")) m.enabled = j.get("enabled").getAsBoolean();
        if (j.has("key")) m.key = j.get("key").getAsInt();
        for (Setting s : m.settings) if (j.has(s.name)) s.value = j.get(s.name).getAsDouble();
      }
    } catch (Exception e) { e.printStackTrace(); }
  }
}
