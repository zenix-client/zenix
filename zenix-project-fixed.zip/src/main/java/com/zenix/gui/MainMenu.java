package com.zenix.gui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public class MainMenu extends Screen {
  static final String[] NAMES = {"SINGLEPLAYER", "MULTIPLAYER", "SETTINGS", "QUIT"};
  static final String[] DESC = {"Create and explore worlds", "Join servers", "Graphics, controls, audio", "Exit the game"};
  public MainMenu() { super(Text.literal("ZENIX")); }
  @Override public boolean shouldCloseOnEsc() { return false; }
  int[] card(int i) { int cw = Math.min(220, width / 2 - 20), ch = 70, gx = 12;
    int x0 = width / 2 - cw - gx / 2, y0 = height / 2 - ch - gx / 2;
    return new int[]{x0 + (i % 2) * (cw + gx), y0 + (i / 2) * (ch + gx), cw, ch}; }
  @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}
  @Override public void render(DrawContext c, int mx, int my, float d) {
    SplashScreen.paint(c, width, height);
    for (int i = 0; i < 4; i++) { int[] r = card(i); boolean hov = mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3];
      c.fill(r[0], r[1], r[0] + r[2], r[1] + r[3], hov ? 0xDD14201C : 0xCC0A0F0D);
      c.fill(r[0], r[1], r[0] + 2, r[1] + r[3], hov ? 0xFF00E5A0 : 0x5500E5A0);
      c.drawCenteredTextWithShadow(textRenderer, NAMES[i], r[0] + r[2] / 2, r[1] + 22, 0xFFFFFFFF);
      c.drawCenteredTextWithShadow(textRenderer, DESC[i], r[0] + r[2] / 2, r[1] + 40, 0xFF8A9690); }
    c.drawCenteredTextWithShadow(textRenderer, "ZENIX CLIENT", width / 2, 20, 0xFF00E5A0);
  }
  @Override public boolean mouseClicked(double mx, double my, int b) {
    for (int i = 0; i < 4; i++) { int[] r = card(i);
      if (mx >= r[0] && mx < r[0] + r[2] && my >= r[1] && my < r[1] + r[3]) {
        switch (i) { case 0 -> client.setScreen(new SelectWorldScreen(this)); case 1 -> client.setScreen(new MultiplayerScreen(this));
          case 2 -> client.setScreen(new OptionsScreen(this, client.options)); default -> client.scheduleStop(); }
        return true; } }
    return false;
  }
}
