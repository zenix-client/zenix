package com.zenix.gui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.time.*; import java.time.format.DateTimeFormatter;

public class SplashScreen extends Screen {
  public SplashScreen() { super(Text.literal("ZENIX")); }
  @Override public boolean shouldCloseOnEsc() { return false; }
  @Override public boolean mouseClicked(double x, double y, int b) { client.setScreen(new MainMenu()); return true; }
  @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}
  @Override public void render(DrawContext c, int mx, int my, float d) { paint(c, width, height); 
    double t = System.currentTimeMillis() / 1000.0;
    LocalDateTime n = LocalDateTime.now();
    var tr = textRenderer;
    c.getMatrices().push(); c.getMatrices().translate(width / 2f, height / 2f - 40, 0); c.getMatrices().scale(4, 4, 1);
    c.drawCenteredTextWithShadow(tr, n.format(DateTimeFormatter.ofPattern("HH:mm")), 0, 0, 0xFFFFFFFF); c.getMatrices().pop();
    c.drawCenteredTextWithShadow(tr, n.format(DateTimeFormatter.ofPattern("d MMMM yyyy")), width / 2, height / 2 - 4, 0xFF9AA5A0);
    c.drawCenteredTextWithShadow(tr, "Welcome to ZENIX", width / 2, height / 2 + 14, 0xFF00E5A0);
    int a = (int) (120 + 100 * Math.sin(t * 2));
    c.drawCenteredTextWithShadow(tr, "Click anywhere to continue", width / 2, height - 30, (a << 24) | 0x00E5A0);
  }
  /** Cheap animated background: 3 sine ribbons + 40 particles, only fill() calls. */
  public static void paint(DrawContext c, int w, int h) {
    c.fill(0, 0, w, h, 0xFF000000);
    double t = System.currentTimeMillis() / 1000.0;
    for (int r = 0; r < 3; r++) for (int x = 0; x < w; x += 4) {
      double y = h * (0.35 + 0.15 * r) + Math.sin(x * 0.012 + t * (0.5 + 0.2 * r) + r * 2) * h * 0.08 + Math.sin(x * 0.03 - t) * 6;
      for (int k = 0; k < 14; k++) { int a = (int) (38 * (1 - k / 14.0)); c.fill(x, (int) y + k * 2, x + 4, (int) y + k * 2 + 2, (a << 24) | (r == 1 ? 0x00D8B0 : 0x00C070)); }
    }
    for (int i = 0; i < 40; i++) {
      double px = (Math.sin(i * 12.9898) * 0.5 + 0.5) * w + Math.sin(t * 0.3 + i) * 20;
      double py = ((Math.cos(i * 78.233) * 0.5 + 0.5) * h - t * (8 + i % 5 * 3)) % h; if (py < 0) py += h;
      int a = (int) (60 + 60 * Math.sin(t * 1.5 + i)); c.fill((int) px, (int) py, (int) px + 2, (int) py + 2, (a << 24) | 0x40FFC8);
    }
  }
}
