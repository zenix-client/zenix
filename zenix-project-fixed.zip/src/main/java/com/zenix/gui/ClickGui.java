package com.zenix.gui;
import com.zenix.*; import com.zenix.Module; import com.zenix.Module.Category;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

public class ClickGui extends Screen {
  record Hit(int x, int y, int w, int h, int kind, Module m, Setting s, Category c) {}
  Category sel; String query = ""; Module open, binding; Setting drag; Hit dragHit; int scroll;
  final List<Hit> hits = new ArrayList<>();
  public ClickGui() { super(Text.literal("ZENIX")); }
  @Override public void renderBackground(DrawContext c, int mx, int my, float d) { c.fill(0, 0, width, height, 0x99000000); }
  int pw() { return Math.min(width - 16, 680); } int ph() { return Math.min(height - 16, 400); }
  int px() { return (width - pw()) / 2; } int py() { return (height - ph()) / 2; }

  void layout() {
    hits.clear(); int x = px(), y = py(), side = Math.min(120, pw() / 4);
    int cy = y + 40;
    hits.add(new Hit(x + 8, cy, side - 16, 20, 0, null, null, null)); cy += 22;
    for (Category c : Category.values()) { if (Zenix.MODULES.stream().noneMatch(m -> m.cat == c)) continue; hits.add(new Hit(x + 8, cy, side - 16, 20, 0, null, null, c)); cy += 22; }
    int cx = x + side + 8, cw = pw() - side - 16, cols = Math.max(1, cw / 200), w = (cw - (cols - 1) * 8) / cols;
    int[] colY = new int[cols]; Arrays.fill(colY, y + 44 - scroll);
    for (Module m : Zenix.MODULES) {
      if (sel != null && m.cat != sel) continue; if (!query.isEmpty() && !m.name.toLowerCase().contains(query.toLowerCase())) continue;
      int col = 0; for (int i = 1; i < cols; i++) if (colY[i] < colY[col]) col = i;
      int bx = cx + col * (w + 8), by = colY[col], h = 30;
      hits.add(new Hit(bx, by, w, 30, 1, m, null, null)); by += 30;
      if (open == m) { for (Setting s : m.settings) { hits.add(new Hit(bx, by, w, 22, s.bool ? 3 : 4, m, s, null)); by += 22; h += 22; }
        hits.add(new Hit(bx, by, w, 22, 5, m, null, null)); h += 22; }
      colY[col] += h + 8;
    }
  }

  @Override public void render(DrawContext c, int mx, int my, float d) {
    renderBackground(c, mx, my, d); layout();
    int x = px(), y = py(), side = Math.min(120, pw() / 4);
    c.fill(x, y, x + pw(), y + ph(), 0xF0101012); c.fill(x, y, x + side, y + ph(), 0xF00B0B0D);
    c.drawText(textRenderer, "ZENIX", x + 12, y + 12, 0xFFFFFFFF, true);
    c.fill(x + side + 8, y + 8, x + pw() - 8, y + 28, 0xFF1A1A1E);
    c.drawText(textRenderer, query.isEmpty() ? "Search..." : query + "_", x + side + 14, y + 14, query.isEmpty() ? 0xFF666666 : 0xFFFFFFFF, false);
    c.enableScissor(x, y + 36, x + pw(), y + ph());
    for (Hit h : hits) {
      boolean hov = mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h;
      switch (h.kind) {
        case 0 -> { boolean on = sel == h.c; c.fill(h.x, h.y, h.x + h.w, h.y + h.h, on ? 0xFF26262B : hov ? 0xFF18181C : 0x00000000);
          c.drawText(textRenderer, h.c == null ? "All" : cap(h.c.name()), h.x + 8, h.y + 6, on ? 0xFFFFFFFF : 0xFF9A9AA0, false); }
        case 1 -> { c.fill(h.x, h.y, h.x + h.w, h.y + h.h, hov ? 0xFF222226 : 0xFF1A1A1E);
          c.drawText(textRenderer, h.m.name, h.x + 8, h.y + 11, 0xFFFFFFFF, false);
          int sx = h.x + h.w - 30; c.fill(sx, h.y + 9, sx + 22, h.y + 21, h.m.enabled ? 0xFFE8E8E8 : 0xFF3A3A40);
          int kx = h.m.enabled ? sx + 12 : sx + 2; c.fill(kx, h.y + 11, kx + 8, h.y + 19, h.m.enabled ? 0xFF111111 : 0xFF888888); }
        case 3 -> { c.fill(h.x, h.y, h.x + h.w, h.y + h.h, 0xFF141417); c.drawText(textRenderer, h.s.name, h.x + 8, h.y + 7, 0xFFC0C0C6, false);
          c.fill(h.x + h.w - 20, h.y + 6, h.x + h.w - 8, h.y + 16, h.s.on() ? 0xFFE8E8E8 : 0xFF3A3A40); }
        case 4 -> { c.fill(h.x, h.y, h.x + h.w, h.y + h.h, 0xFF141417);
          c.drawText(textRenderer, h.s.name + ": " + (int) h.s.value, h.x + 8, h.y + 3, 0xFFC0C0C6, false);
          int bw = h.w - 16; c.fill(h.x + 8, h.y + 16, h.x + 8 + bw, h.y + 19, 0xFF2E2E34);
          int fw = (int) (bw * (h.s.value - h.s.min) / (h.s.max - h.s.min)); c.fill(h.x + 8, h.y + 16, h.x + 8 + fw, h.y + 19, 0xFFE0E0E0); }
        case 5 -> { c.fill(h.x, h.y, h.x + h.w, h.y + h.h, 0xFF141417);
          String k = binding == h.m ? "press a key..." : h.m.key < 0 ? "None" : InputUtil.fromKeyCode(h.m.key, 0).getLocalizedText().getString();
          c.drawText(textRenderer, "Key: " + k, h.x + 8, h.y + 7, 0xFFC0C0C6, false); }
      }
    }
    c.disableScissor();
  }
  static String cap(String s) { return s.charAt(0) + s.substring(1).toLowerCase(); }

  void setSlider(Hit h, double mx) { double f = Math.max(0, Math.min(1, (mx - h.x - 8) / (h.w - 16))); h.s.value = Math.round(h.s.min + f * (h.s.max - h.s.min)); }

  @Override public boolean mouseClicked(double mx, double my, int b) {
    layout(); binding = null;
    if (my < py() + 36 && my > py()) return true;
    for (Hit h : hits) if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) {
      switch (h.kind) {
        case 0 -> { sel = h.c; scroll = 0; }
        case 1 -> { if (mx > h.x + h.w - 36 && b == 0) h.m.toggle(); else open = open == h.m ? null : h.m; }
        case 3 -> h.s.value = h.s.on() ? 0 : 1;
        case 4 -> { drag = h.s; dragHit = h; setSlider(h, mx); }
        case 5 -> binding = h.m;
      } return true; }
    return super.mouseClicked(mx, my, b);
  }
  @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) { if (drag != null) { setSlider(dragHit, mx); return true; } return false; }
  @Override public boolean mouseReleased(double mx, double my, int b) { drag = null; return false; }
  @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll = Math.max(0, scroll - (int) (v * 20)); return true; }
  @Override public boolean charTyped(char ch, int mod) { if (binding == null && ch >= 32) { query += ch; scroll = 0; return true; } return false; }
  @Override public boolean keyPressed(int key, int sc, int mod) {
    if (binding != null) { binding.key = key == GLFW.GLFW_KEY_ESCAPE ? -1 : key; binding = null; return true; }
    if (key == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) { query = query.substring(0, query.length() - 1); return true; }
    if (key == GLFW.GLFW_KEY_RIGHT_SHIFT && Zenix.clickgui.key == key) { close(); return true; }
    return super.keyPressed(key, sc, mod);
  }
  @Override public void close() { Zenix.save(); super.close(); }
  @Override public boolean shouldPause() { return false; }
}
