package com.zenix;
import java.util.*;
public class Module {
  public enum Category { COMBAT, MOVEMENT, PLAYER, RENDER, VISUAL, CLIENT }
  public final String name; public final Category cat; public boolean enabled; public int key = -1;
  public final List<Setting> settings = new ArrayList<>();
  public Module(String n, Category c) { name = n; cat = c; }
  public Module add(Setting s) { settings.add(s); return this; }
  public Setting get(String n) { for (Setting s : settings) if (s.name.equals(n)) return s; throw new IllegalArgumentException(n); }
  public void toggle() { enabled = !enabled; }
}
