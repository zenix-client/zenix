package com.zenix.mixin;
import com.zenix.Zenix;
import net.minecraft.client.render.*;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
  @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
  private static void zenix$fog(Camera camera, BackgroundRenderer.FogType fogType, Vector4f color, float viewDistance,
                                boolean thickenFog, float tickDelta, CallbackInfoReturnable<Fog> cir) {
    var a = Zenix.ambience;
    if (a == null || !a.enabled || !a.get("Fog").on() || fogType != BackgroundRenderer.FogType.FOG_TERRAIN) return;
    Fog f = cir.getReturnValue();
    float end = Math.max(8f, viewDistance * a.get("Fog Distance %").f() / 100f);
    float start = end * (0.95f - 0.9f * a.get("Fog Density %").f() / 100f);
    cir.setReturnValue(new Fog(start, end, f.shape(),
      a.get("Fog Red").f() / 255f, a.get("Fog Green").f() / 255f, a.get("Fog Blue").f() / 255f, f.alpha()));
  }
  // keeps sky/clear colour equal to fog colour so there is no visible seam
  @Inject(method = "getFogColor", at = @At("RETURN"), cancellable = true)
  private static void zenix$fogColor(CallbackInfoReturnable<Vector4f> cir) {
    var a = Zenix.ambience;
    if (a == null || !a.enabled || !a.get("Fog").on()) return;
    cir.setReturnValue(new Vector4f(a.get("Fog Red").f() / 255f, a.get("Fog Green").f() / 255f, a.get("Fog Blue").f() / 255f, 1f));
  }
}
